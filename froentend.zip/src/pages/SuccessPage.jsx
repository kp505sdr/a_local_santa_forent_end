// import React from 'react'
// import { useLocation } from 'react-router-dom'


// const SuccessPage = async() => {
//     const location = useLocation();

//     const searchParams = new URLSearchParams(location.search);
//     const sessionId = searchParams.get('session_id');
//     console.log(sessionId);


//   return (
//     <div>Payment Success</div>
//   )
// }

// export default SuccessPage

import axios from 'axios';
import React, { useEffect, useState } from 'react';

const SuccessPage = () => {
  const [sessionId,setsessionid]=useState()
    const [paymentReceived, setPaymentReceived] = useState(false);

    useEffect(() => {
        // Check if the URL contains the success parameter indicating a successful payment
        const urlParams = new URLSearchParams(window.location.search);
        const sessionid = urlParams.get('session_id');
        setsessionid(sessionid)

        if (sessionid) {
            setPaymentReceived(true);
       
            // Optionally, you can perform additional actions here
        }
 
    }, []);

// --------------------------------------------------------------------
const callStripeWebhook = async () => {
  try {
    const response = await axios.post(`${process.env.REACT_APP_API}/api/v1/webhook`,{ });

    console.log("webhook working",response)
  } catch (error) {
    console.error('Error calling Stripe webhook:', error);
  }
};
//  --------------------------------------------------------------------  
    return (
        <div>
            {paymentReceived ? (
            <>
                <h2>Payment Successful!</h2>
                <p>sessionId: {sessionId}</p></>
            ) : (
                <h2>Payment Not Yet Received</h2>
            )}
           <div>
   
    </div>

        </div>
    );
};

export default SuccessPage;
