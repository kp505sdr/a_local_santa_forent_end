import React from "react";
import { Link } from "react-router-dom";

const CommentTable = () => {
  return (
    <div className="-my-2 py-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 pr-10 lg:px-8">
      <div className="align-middle rounded-tl-lg rounded-tr-lg inline-block w-full overflow-hidden px-2 py-3">
        <div className="flex justify-between items-center">
          <div className=""> All Comments</div>
        </div>
      </div>
      <div className="align-middle inline-block min-w-full shadow overflow-hidden  shadow-dashboard rounded-bl-lg rounded-br-lg">
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs md:text-sm leading-4 tracking-wider">
                S No.
              </th>
              <th className="px-6 py-3 text-left text-xs md:text-sm leading-4 tracking-wider">
                ID
              </th>
              <th className="px-6 py-3 text-left text-xs md:text-sm leading-4 tracking-wider">
                Title
              </th>
              {/* <th className="px-3 py-3 text-left text-xs md:text-sm leading-4 tracking-wider cursor-pointer">
                <span className=" px-3 rounded-3xl">+10 View</span>
              </th> */}
              <th className="px-6 py-3 text-left text-xs md:text-sm leading-4 tracking-wider">
                Comment Qty
              </th>
              <th className="px-6 py-3 text-left text-xs md:text-sm leading-4 tracking-wider">
                Details
              </th>
            </tr>
          </thead>
          <tbody className="bg-white">
            <tr className="border-b border-gray-500">
              <td className="px-6 whitespace-no-wrap">1</td>
              <td className="px-6 whitespace-nowrap text-blue-900 border-gray-500 text-xs md:text-sm leading-5">
                123456
              </td>{" "}
              <td className="flex items-center gap-x-2 px-6 py-5 whitespace-nowrap border-gray-500">
                {/* <img
                  src="https://plus.unsplash.com/premium_photo-1712416361680-660f671cd797?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                  alt=""
                  className="w-5 h-5 rounded-full"
                /> */}
                <div className="text-xs md:text-sm leading-5 text-blue-900">
                  Damilare Anjorin
                </div>
              </td>
              {/* <td className="px-6 whitespace-nowrap text-blue-900 border-gray-500 text-xs md:text-sm leading-5">
                <img
                  src="https://plus.unsplash.com/premium_photo-1712416361680-660f671cd797?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                  alt=""
                  className="w-8 h-8 rounded-full"
                />
              </td>{" "} */}
              <td className="px-6 whitespace-nowrap text-blue-900 border-gray-500 text-xs md:text-sm leading-5">
                <span className="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                  <span aria-hidden className="absolute inset-0 " />
                  <span className="relative text-xs sm:text-sm ">10</span>
                </span>
              </td>
              <td className="px-6 whitespace-nowrap text-blue-900 border-gray-500 text-xs md:text-sm leading-5">
                <Link
                  to="/comments-view"
                  className="bg-yellow-300 px-2 py-1 rounded-md text-white"
                >
                  View
                </Link>
              </td>
              {/* <td className="px-6 whitespace-no-wrap text-blue-900 text-xs md:text-sm leading-5">
                <button className="px-5 py-2 border text-blue-500 rounded-full transition duration-300 hover:bg-blue-700 hover:text-white focus:outline-none whitespace-nowrap">
                  View Request 1
                </button>
              </td> */}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CommentTable;
